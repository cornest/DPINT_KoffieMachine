# DPINT_Wk456_Koffiemachine
De opdracht voor Design Patterns Introductie van week 4, 5 en 6.
