﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoffieMachineDomain
{
    public enum Strength
    {
        Normal = 0, Weak, Strong
    }
}
