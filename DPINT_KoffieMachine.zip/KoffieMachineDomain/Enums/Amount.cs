﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KoffieMachineDomain
{
    public enum Amount
    {
        Normal = 0, Few, Extra
    }
}
